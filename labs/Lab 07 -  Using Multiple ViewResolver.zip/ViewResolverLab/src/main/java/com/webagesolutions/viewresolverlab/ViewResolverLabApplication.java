package com.webagesolutions.viewresolverlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViewResolverLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViewResolverLabApplication.class, args);
	}

}
