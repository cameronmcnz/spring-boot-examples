package com.webagesolutions.viewresolverlab.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
	
    @RequestMapping(value = { "/thymeleaf-page" }, method = RequestMethod.GET)
    public String getThymeleafView() {
 
        return "th_page1";
    }
 
    @RequestMapping(value = { "/freemarker-page" }, method = RequestMethod.GET)
    public String getFreeMarkerView() {
     
            return "freemarker-page";
    }
    
    @RequestMapping(value = { "/jsp-page" }, method = RequestMethod.GET)
    public String getJspView() {
     
        return "jsp-page";
    }
}