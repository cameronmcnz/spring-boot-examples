package com.webagesolutions.viewresolverlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewResolverLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
