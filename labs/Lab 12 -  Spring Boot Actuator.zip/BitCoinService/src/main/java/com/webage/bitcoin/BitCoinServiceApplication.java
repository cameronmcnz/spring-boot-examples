package com.webage.bitcoin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitCoinServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitCoinServiceApplication.class, args);
	}

}
