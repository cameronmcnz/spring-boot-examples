package com.webage.bitcoin;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PriceController {
	
	private static final double MIN_PRICE = 1.00;     
	private static final double MAX_PRICE = 100000.00; 

	@GetMapping("/price")
	public String getPrice() {

	  double price = ThreadLocalRandom.current()
	                   .nextDouble( MIN_PRICE, MAX_PRICE + 1 );

	  NumberFormat formatter = NumberFormat.getCurrencyInstance();

	  formatter.setCurrency( Currency.getInstance(Locale.US) );

	  return "Current Bitcoin price: " + 
	         formatter.format(price);

	}
}
