package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.Principal;

@RestController
@SpringBootApplication
public class DemoApplication extends WebSecurityConfigurerAdapter {

	@GetMapping("/user")
	public Principal user(Principal principal) {
	return principal;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.csrf(c -> c
				.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
			)
			.logout(log -> log.logoutSuccessUrl("/").permitAll())		

		.authorizeRequests(a -> a
			.antMatchers("/", "/error", "/webjars/**").permitAll()
			.anyRequest().authenticated()
		)
		.exceptionHandling(e -> e
			.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))
		)
		.oauth2Login();
	}


	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
