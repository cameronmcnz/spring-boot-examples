package com.webage.restaurant.services;

import com.webage.restaurant.data.Restaurant;
import com.webage.restaurant.data.repo.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RestaurantServiceImpl implements RestaurantService {

  @Autowired
  private RestaurantRepository restaurantRepository;

  public Optional<Restaurant> getRestaurant(Long id) {
    System.out.println("RestaurantReviewService: getRestaurant("+id+")");
    return restaurantRepository.findById(id);
  }

  public Iterable<Restaurant> getAllRestaurants() {
    System.out.println("RestaurantReviewService: getAllRestaurants()");
    return restaurantRepository.findAll();
  }

  public Restaurant insertRestaurant( Restaurant restaurant ) {
    System.out.println("RestaurantReviewService: insertRestaurant("+restaurant.getName()+")");
    return restaurantRepository.save(restaurant);
  }
}
