package com.webage.restaurant.data;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
public class Restaurant {

  protected Restaurant(){}

  public Restaurant(@NotNull String name) {
    this.name = name;
  }

  public Restaurant(String name, Long restaurant_id, Long cuisine_id) {
    this.restaurant_id = restaurant_id;
    this.name = name;
    this.cuisine_id = cuisine_id;
  }

  @Id
  @GeneratedValue(strategy= GenerationType.IDENTITY)
  private Long restaurant_id;

  @NotNull
  private String name;

  @NotNull
  private Long cuisine_id;


}
