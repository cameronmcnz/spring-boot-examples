package com.webage.restaurant.services;

import com.webage.restaurant.data.Restaurant;

import java.util.Optional;

public interface RestaurantService {

  public Optional<Restaurant> getRestaurant(Long id);

  public Iterable<Restaurant> getAllRestaurants();

  public Restaurant insertRestaurant( Restaurant restaurant );

}
