insert into restaurant (name, cuisine_id) values ('Brazil, Brazil!',1);
insert into restaurant (name, cuisine_id) values ('Fuki Sushi',2);
insert into restaurant (name, cuisine_id) values ('La Tasca',3);
insert into restaurant (name, cuisine_id) values ('Flame',1);
insert into restaurant (name, cuisine_id) values ('Blowfish',2);
insert into restaurant (name, cuisine_id) values ('Plaza de Toros',3);

