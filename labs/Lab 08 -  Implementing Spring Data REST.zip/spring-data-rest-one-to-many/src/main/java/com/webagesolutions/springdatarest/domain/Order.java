package com.webagesolutions.springdatarest.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity( name ="orders")
public class Order {
	
	@Id
	@GeneratedValue
	private Long id;
	private String orderDate;
	private Float amount;
	
	@ManyToOne(fetch=FetchType.EAGER)
	private Customer customer;
	
	public Order() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String name) {
		this.orderDate = name;
	}

	@Override
	public String toString() {
		return String.format("Order [id=%d, orderDate=%d, amount=%f]", id, orderDate, amount);
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}
}