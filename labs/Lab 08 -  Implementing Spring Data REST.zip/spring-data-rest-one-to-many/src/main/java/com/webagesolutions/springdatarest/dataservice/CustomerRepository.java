package com.webagesolutions.springdatarest.dataservice;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.webagesolutions.springdatarest.domain.Customer;

@RepositoryRestResource(path = "customers", collectionResourceRel = "customers")
public interface CustomerRepository extends PagingAndSortingRepository<Customer, Long> {

}