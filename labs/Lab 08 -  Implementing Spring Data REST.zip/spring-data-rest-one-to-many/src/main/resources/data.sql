insert into customers
values(1001, 'Bobby');

insert into customers
values(1002,'Drew');

insert into orders
values (1, 99.95, '2010-10-01', 1001);
insert into orders
values (2, 149.95, '2015-05-03', 1002);
insert into orders
values (3, 49.95, '2018-08-07', 1002);
insert into orders
values (4, 19.95, '2021-01-02', 1001);