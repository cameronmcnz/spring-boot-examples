package com.webagesolutions.controllers_lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringControllerApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringControllerApplication.class, args);
	}
}
