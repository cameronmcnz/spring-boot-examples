package com.webagesolutions.controllers_lab.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.env.Environment;

import com.webagesolutions.controllers_lab.domain.Product;
import com.webagesolutions.controllers_lab.repository.ProductRepository;

public class CustomRunner implements ApplicationRunner {

	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	Environment env;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		Product item1 = new Product(env.getProperty("ITEM1"));
		Product item2 = new Product(env.getProperty("ITEM2"));

		productRepository.save(item1);
		productRepository.save(item2);
	}
	
	
	
}
