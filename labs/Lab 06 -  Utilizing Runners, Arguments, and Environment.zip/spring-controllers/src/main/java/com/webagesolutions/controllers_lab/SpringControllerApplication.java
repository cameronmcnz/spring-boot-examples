package com.webagesolutions.controllers_lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.webagesolutions.controllers_lab.runners.CustomRunner;

@SpringBootApplication
public class SpringControllerApplication {

	@Bean
	public CustomRunner appStartupRunner() {
		return new CustomRunner();
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringControllerApplication.class, args);
	}

}
