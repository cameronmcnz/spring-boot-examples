insert into CUSTOMERS (CUSTOMER_NAME, EMAIL) VALUES ('Bruce', 'bruce@a.com');
insert into CUSTOMERS (CUSTOMER_NAME, EMAIL) VALUES ('Paul', 'paul@b.com');
insert into CUSTOMERS (CUSTOMER_NAME, EMAIL) VALUES ('Rick', 'rick@c.com');

insert into PURCHASES (PRODUCT, PURCHASE_DATE, CUSTOMER_ID)
values('Mountain Bike','2010-05-12 00:00:00.0',1);
insert into PURCHASES (PRODUCT, PURCHASE_DATE, CUSTOMER_ID)
values('Football','2010-04-30 00:00:00.0',2);
insert into PURCHASES (PRODUCT, PURCHASE_DATE, CUSTOMER_ID)
values('Kayak','2010-06-05 00:00:00.0',3);
