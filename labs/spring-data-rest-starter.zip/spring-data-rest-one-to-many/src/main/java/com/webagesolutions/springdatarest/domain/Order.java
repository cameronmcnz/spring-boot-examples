package com.webagesolutions.springdatarest.domain;

public class Order {
	private Long id;
	private String orderDate;
	private Float amount;
	
	private Customer customer;
	
	public Order() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String name) {
		this.orderDate = name;
	}

	@Override
	public String toString() {
		return String.format("Order [id=%d, orderDate=%d, amount=%f]", id, orderDate, amount);
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}
}