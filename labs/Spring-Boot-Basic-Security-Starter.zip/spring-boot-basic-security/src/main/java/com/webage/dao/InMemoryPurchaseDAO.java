package com.webage.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.webage.domain.Purchase;

@Repository
public class InMemoryPurchaseDAO implements PurchaseDAO {

	private Map<Integer, Purchase> purchases = new HashMap<>();

	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			savePurchase(new Purchase(1, "Susan", df.parse("2010-05-12"), "Mountain Bike"));
			savePurchase(new Purchase(2, "Bob", df.parse("2010-04-30"), "Football"));
			savePurchase(new Purchase(3, "Jill", df.parse("2010-05-06"), "Kayak"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void savePurchase(Purchase purchase) {
		purchases.put(purchase.getId(), purchase);
	}

	@Override
	public Collection<Purchase> getAllPurchases() {
		return purchases.values();
	}

	@Override
	public Purchase getPurchase(int id) {
		return purchases.get(id);
	}

}
